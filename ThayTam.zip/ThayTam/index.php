<?php
include('db.php');

$sql = "SELECT * FROM articles ORDER BY created_at DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<h2>" . $row["title"]. "</h2>";
        echo "<p>" . substr($row["content"], 0, 200) . "...</p>";
        echo "<a href='article.php?id=" . $row["id"] . "'>Read more</a><br><br>";
    }
} else {
    echo "No articles found";
}

$conn->close();
?>
