<?php
include('db.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Lấy bài viết
    $sql = "SELECT * FROM articles WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo "<h2>" . $row["title"] . "</h2>";
        echo "<p>" . $row["content"] . "</p>";

      
        $comment_sql = "SELECT * FROM comments WHERE article_id = $id ORDER BY created_at DESC";
        $comments = $conn->query($comment_sql);
        echo "<h3>Comments</h3>";
        while ($comment = $comments->fetch_assoc()) {
            echo "<p><strong>" . $comment["author"] . ":</strong> " . $comment["content"] . "</p>";
        }

        
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $author = $_POST['author'];
            $content = $_POST['content'];
            $comment_sql = "INSERT INTO comments (article_id, author, content) VALUES ($id, '$author', '$content')";
            $conn->query($comment_sql);
            header("Location: article.php?id=$id");
            exit();
        }
    } else {
        echo "Article not found.";
    }
}

$conn->close();
?>

<h3>Add Comment</h3>
<form method="post" action="">
    <input type="text" name="author" placeholder="Your Name" required><br><br>
    <textarea name="content" placeholder="Your Comment" required></textarea><br><br>
    <input type="submit" value="Post Comment">
</form>
