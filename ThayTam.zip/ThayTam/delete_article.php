<?php
include('admin_check.php'); 
include('db.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    $sql = "DELETE FROM articles WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        header('Location: admin_dashboard.php');
        exit();
    } else {
        echo "Error deleting article: " . $conn->error;
    }
}

$conn->close();
?>
