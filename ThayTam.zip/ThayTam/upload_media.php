<?php
include('admin_check.php');
include('db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['media'])) {
    $file = $_FILES['media'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];

    $file_ext = strtolower(end(explode('.', $file_name)));
    $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'mp4', 'avi'];

    if (in_array($file_ext, $allowed_ext)) {
        $new_file_name = uniqid('', true) . '.' . $file_ext;
        $file_destination = 'uploads/' . $new_file_name;

        if (move_uploaded_file($file_tmp, $file_destination)) {
            $sql = "INSERT INTO media (file_path, file_type) VALUES ('$file_destination', '$file_ext')";
            if ($conn->query($sql) === TRUE) {
                echo "File uploaded successfully!";
            } else {
                echo "Error uploading file.";
            }
        } else {
            echo "Error moving file.";
        }
    } else {
        echo "Invalid file type.";
    }
}

$conn->close();
?>

<form method="post" enctype="multipart/form-data" action="">
    <input type="file" name="media" required><br><br>
    <input type="submit" value="Upload Media">
</form>
