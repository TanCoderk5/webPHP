<?php
session_start();

// Kiểm tra xem người dùng đã đăng nhập chưa
if (!isset($_SESSION['role'])) {
    // Nếu không có vai trò, điều hướng người dùng đến trang đăng nhập
    header("Location: login.php");
    exit();
}

// Lấy vai trò từ session
$role = $_SESSION['role'];

// Kiểm tra vai trò và hiển thị tính năng tương ứng
if ($role == 'admin') {
    echo "<h1>Welcome, Admin!</h1>";
    echo "<p>You have full access to all features.</p>";
    // Hiển thị tất cả tính năng cho Admin
    echo "<ul>
            <li><a href='add_article.php'>Add Article</a></li>
            <li><a href='edit_article.php'>Edit Article</a></li>
            <li><a href='delete_article.php'>Delete Article</a></li>
            <li><a href='manage_users.php'>Manage Users</a></li>
          </ul>";
    
} elseif ($role == 'editor') {
    echo "<h1>Welcome, Editor!</h1>";
    echo "<p>You can edit and manage articles, but cannot add new articles.</p>";
    // Hiển thị các tính năng cho Editor
    echo "<ul>
            <li><a href='edit_article.php'>Edit Article</a></li>
            <li><a href='delete_article.php'>Delete Article</a></li>
          </ul>";
    
} elseif ($role == 'author') {
    echo "<h1>Welcome, Author!</h1>";
    echo "<p>You can only add new articles.</p>";
    // Hiển thị các tính năng cho Author
    echo "<ul>
            <li><a href='add_article.php'>Add Article</a></li>
          </ul>";
    
} else {
    // Nếu vai trò không hợp lệ, yêu cầu người dùng đăng nhập lại
    echo "<p>Your role is not recognized. Please contact the admin.</p>";
    // Điều hướng về trang đăng nhập nếu không phải admin, editor hoặc author
    header("Location: login.php");
    exit();
}
?>

