<form method="get" action="search.php">
    <input type="text" name="search" placeholder="Search Articles" required><br><br>
    <select name="category_id">
        <option value="">All Categories</option>
        <?php
        // Lấy danh sách danh mục
        include('db.php');
        $sql = "SELECT * FROM categories";
        $categories = $conn->query($sql);
        while ($category = $categories->fetch_assoc()) {
            echo "<option value='" . $category['id'] . "'>" . $category['name'] . "</option>";
        }
        ?>
    </select><br><br>
    <input type="submit" value="Search">
</form>
<?php
include('db.php');

$search = $_GET['search'] ?? '';
$category_id = $_GET['category_id'] ?? '';

$sql = "SELECT * FROM articles WHERE title LIKE '%$search%'";

if ($category_id != '') {
    $sql .= " AND category_id = $category_id";
}

$result = $conn->query($sql);

echo "<h2>Search Results</h2>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<h3>" . $row["title"] . "</h3>";
        echo "<p>" . substr($row["content"], 0, 200) . "...</p>";
        echo "<a href='article.php?id=" . $row["id"] . "'>Read more</a><br><br>";
    }
} else {
    echo "No articles found.";
}

$conn->close();
?>
