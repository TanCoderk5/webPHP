<?php
include('admin_check.php');
include('db.php');

$sql = "SELECT * FROM articles ORDER BY created_at DESC";
$result = $conn->query($sql);

echo "<h2>Admin Dashboard</h2>";
echo "<a href='add_article.php'>Add New Article</a><br><br>";

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<h3>" . $row["title"] . "</h3>";
        echo "<p>" . substr($row["content"], 0, 200) . "...</p>";
        echo "<a href='edit_article.php?id=" . $row["id"] . "'>Edit</a> | ";
        echo "<a href='delete_article.php?id=" . $row["id"] . "'>Delete</a><br><br>";
    }
} else {
    echo "No articles found.";
}

$conn->close();
?>
