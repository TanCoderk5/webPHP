<?php
include('admin_check.php'); // Kiểm tra quyền truy cập admin
include('db.php'); // Kết nối cơ sở dữ liệu

// Lấy danh sách danh mục từ database
$sql = "SELECT * FROM categories";
$categories = $conn->query($sql);

// Kiểm tra nếu form được gửi
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lấy dữ liệu từ form
    $title = $_POST['title'];
    $content = $_POST['content'];
    $author = $_POST['author'];
    $category_id = $_POST['category_id'];
    $publish_at = $_POST['publish_at']; // Thời gian đăng bài (nếu có)

    // Truy vấn thêm bài viết vào cơ sở dữ liệu
    $sql = "INSERT INTO articles (title, content, author, category_id, publish_at) 
            VALUES ('$title', '$content', '$author', '$category_id', '$publish_at')";
    
    // Thực hiện truy vấn và kiểm tra kết quả
    if ($conn->query($sql) === TRUE) {
        header('Location: admin_dashboard.php');  // Quay lại trang dashboard sau khi thêm bài viết
        exit();
    } else {
        echo "Error: " . $conn->error;  // Nếu có lỗi
    }
}

$conn->close(); // Đóng kết nối CSDL
?>

<!-- Form Thêm Bài Viết -->
<form method="post" action="">
    <input type="text" name="title" placeholder="Title" required><br><br>
    <textarea name="content" placeholder="Content" required></textarea><br><br>
    <input type="text" name="author" placeholder="Author" required><br><br>

    <!-- Chọn danh mục -->
    <select name="category_id" required>
        <?php while ($category = $categories->fetch_assoc()) { ?>
            <option value="<?php echo $category['id']; ?>"><?php echo $category['name']; ?></option>
        <?php } ?>
    </select><br><br>

    <!-- Lên lịch đăng bài -->
    <input type="datetime-local" name="publish_at" placeholder="Publish At"><br><br>

    <input type="submit" value="Add Article">
</form>
