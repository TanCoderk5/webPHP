<?php
include('db.php');

$sql = "SELECT * FROM articles WHERE publish_at <= NOW() AND published = 0";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    $update_sql = "UPDATE articles SET published = 1 WHERE id = " . $row['id'];
    $conn->query($update_sql);
}

$conn->close();
?>
