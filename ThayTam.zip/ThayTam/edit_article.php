<?php
include('admin_check.php'); 
include('db.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    
    $sql = "SELECT * FROM articles WHERE id = $id";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "Article not found.";
        exit();
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $title = $_POST['title'];
        $content = $_POST['content'];
        $author = $_POST['author'];

        $update_sql = "UPDATE articles SET title = '$title', content = '$content', author = '$author' WHERE id = $id";

        if ($conn->query($update_sql) === TRUE) {
            header('Location: admin_dashboard.php');
            exit();
        } else {
            echo "Error updating article: " . $conn->error;
        }
    }
} else {
    echo "Invalid article ID.";
}

$conn->close();
?>

<form method="post" action="">
    <input type="text" name="title" value="<?php echo $row['title']; ?>" required><br><br>
    <textarea name="content" required><?php echo $row['content']; ?></textarea><br><br>
    <input type="text" name="author" value="<?php echo $row['author']; ?>" required><br><br>
    <input type="submit" value="Update Article">
</form>
