<?php
include('admin_check.php'); 
include('db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];

    $sql = "INSERT INTO categories (name, description) VALUES ('$name', '$description')";
    
    if ($conn->query($sql) === TRUE) {
        header('Location: admin_dashboard.php'); 
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<form method="post" action="">
    <input type="text" name="name" placeholder="Category Name" required><br><br>
    <textarea name="description" placeholder="Category Description"></textarea><br><br>
    <input type="submit" value="Add Category">
</form>
